export default [

  {
    title : 'Overall',
    icon : 'icon-world-ranking'
  },
  {
    title : 'Finance',
    icon : 'icon-economy'
  },
  {
    title : 'Industry',
    icon : 'icon-industry'
  },
  {
    title : 'Infrastructure',
    icon : 'icon-infrastructure'
  },
  {
    title : 'Labour',
    icon : 'icon-labor'
  },
  {
    title : 'Security',
    icon : 'icon-security'
  },
  {
    title : 'Justice',
    icon : 'icon-justice'
  },
  {
    title : 'Social',
    icon : 'icon-social'
  },
  {
    title : 'Technology',
    icon : 'icon-technology'
  },
  {
    title : 'Education',
    icon : 'icon-education'
  },
  {
    title : 'Health',
    icon : 'icon-health'
  }

]