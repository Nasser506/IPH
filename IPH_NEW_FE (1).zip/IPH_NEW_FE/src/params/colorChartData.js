const colorChartData = [
    "#b82d31",
    "#d07130",
    "#c8b032",
    "#9eb138",
    "#1c9573",

    "#fff" //white for no data
];

export default colorChartData;
