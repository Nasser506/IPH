export {default as colorChartData} from './colorChartData';
