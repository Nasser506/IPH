const createKPIList = (realms, kpiList = [], path = []) => {

};


export default createKPIList;
