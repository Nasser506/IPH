import {colorChartData} from "../params";

const getColorByDataV3 = (i) => {
    return colorChartData[i];
};

export default getColorByDataV3;
