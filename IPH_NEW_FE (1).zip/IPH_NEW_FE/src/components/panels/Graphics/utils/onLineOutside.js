import ReactDOM from 'react-dom';
import React from 'react';

const onLineOutside = () => {
  ReactDOM.render(<div />, document.getElementById('tooltip-root'));
};

export default onLineOutside;
