export { default as ChooseKPI } from './panels/ChooseKPI/ChooseKPI';
export { default as CompareCountries } from './panels/CompareCountries/CompareCountries';
export { default as SearchCountry } from './panels/CountryDetail/CountryDetail';
export { default as WorldRanking } from './panels/WorldRanking/WorldRanking';
export { default as FullStats } from './panels/FullStats/FullStats';
